#include "iseven.h"

int is_even(int num) {
    return (num % 2 == 0);
}
