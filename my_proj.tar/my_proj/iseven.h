#ifndef ISEVEN_H
#define ISEVEN_H

int is_even(int num);

#endif // ISEVEN_H

