#include "isodd.h"

int is_odd(int num) {
    return (num % 2 != 0);
}
