#ifndef ISODD_H
#define ISODD_H

int is_odd(int num);

#endif // ISODD_H
